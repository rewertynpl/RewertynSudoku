// Thin header wrapper for geometry definitions.
// The implementation lives in `strategie_main.cpp` but is used as a header.
#pragma once

#include "strategie_main.cpp"

