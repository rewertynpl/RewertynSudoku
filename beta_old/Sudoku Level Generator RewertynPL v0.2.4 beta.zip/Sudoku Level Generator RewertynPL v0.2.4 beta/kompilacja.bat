@echo off
set "NO_PAUSE="
if /I "%~1"=="--no-pause" set "NO_PAUSE=1"
powershell -NoProfile -ExecutionPolicy Bypass -File "audit_hpc_hotpath.ps1"
if errorlevel 1 (
    echo HPC hot-path audit failed.
    if not defined NO_PAUSE pause
    exit /b %errorlevel%
)
g++ -std=c++20 -O2 "Sudoku Level Generator RewertynPL.cpp" -o "sudoku_gen_test.exe" -lcomctl32 -lcomdlg32  -lshell32 -lole32 -lgdi32 -lpsapi -static
if not defined NO_PAUSE pause
