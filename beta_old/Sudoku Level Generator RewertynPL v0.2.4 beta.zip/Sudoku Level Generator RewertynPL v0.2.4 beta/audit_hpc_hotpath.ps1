$ErrorActionPreference = 'Stop'

function Remove-CommentsFromLine {
    param(
        [string]$Line,
        [ref]$InBlockComment
    )

    $sb = [System.Text.StringBuilder]::new()
    $i = 0
    while ($i -lt $Line.Length) {
        if ($InBlockComment.Value) {
            $endIdx = $Line.IndexOf('*/', $i, [System.StringComparison]::Ordinal)
            if ($endIdx -lt 0) {
                $i = $Line.Length
                break
            }
            $InBlockComment.Value = $false
            $i = $endIdx + 2
            continue
        }

        if (($i + 1) -lt $Line.Length) {
            $pair = $Line.Substring($i, 2)
            if ($pair -eq '/*') {
                $InBlockComment.Value = $true
                $i += 2
                continue
            }
            if ($pair -eq '//') {
                break
            }
        }

        [void]$sb.Append($Line[$i])
        ++$i
    }

    return $sb.ToString()
}

function Add-ScanTarget {
    param(
        [System.Collections.Generic.List[object]]$Targets,
        [string]$Path,
        [string]$Mode
    )

    if (Test-Path -LiteralPath $Path) {
        $Targets.Add([pscustomobject]@{
            Path = $Path
            Mode = $Mode
        })
    }
}

$repoRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$targets = [System.Collections.Generic.List[object]]::new()

foreach ($logicDir in @(
    'Sources\logic\p1_easy',
    'Sources\logic\p2_intersections',
    'Sources\logic\p3_subsets',
    'Sources\logic\p4_hard',
    'Sources\logic\p5_expert',
    'Sources\logic\p6_diabolical',
    'Sources\logic\p7_nightmare',
    'Sources\logic\p8_theoretical',
    'Sources\logic\shared'
)) {
    Add-ScanTarget -Targets $targets -Path (Join-Path $repoRoot $logicDir) -Mode 'enforced'
}

Add-ScanTarget -Targets $targets -Path (Join-Path $repoRoot 'Sources\generator\mcts_digger') -Mode 'baseline'
Add-ScanTarget -Targets $targets -Path (Join-Path $repoRoot 'Sources\generator\pattern_forcing\pattern_planter.h') -Mode 'baseline'

$forbidden = @(
    @{ Name = 'std::vector'; Pattern = '\bstd::vector\b' },
    @{ Name = 'std::set'; Pattern = '\bstd::set\b' },
    @{ Name = 'std::map'; Pattern = '\bstd::map\b' },
    @{ Name = 'std::deque'; Pattern = '\bstd::deque\b' },
    @{ Name = 'new'; Pattern = '(?<![A-Za-z0-9_])new(?![A-Za-z0-9_])' }
)

$baselineAllowlist = @(
    @{
        Suffix = 'Sources\generator\mcts_digger\bottleneck_digger.h'
        Token = 'std::vector'
        Reason = 'Generator wrapper signatures still expose vector-based puzzle buffers outside the logic hot loop.'
    },
    @{
        Suffix = 'Sources\generator\pattern_forcing\pattern_planter.h'
        Token = 'std::vector'
        Reason = 'Pattern forcing scratch uses pre-sized vectors outside solver logic; tracked separately from zero-alloc solver hot paths.'
    }
)

$violations = [System.Collections.Generic.List[object]]::new()

foreach ($target in $targets) {
    $files = @()
    if ((Get-Item -LiteralPath $target.Path).PSIsContainer) {
        $files = Get-ChildItem -LiteralPath $target.Path -Recurse -File | Where-Object {
            $_.Extension -in @('.h', '.hpp', '.cpp', '.cxx')
        }
    } else {
        $files = @(Get-Item -LiteralPath $target.Path)
    }

    foreach ($file in $files) {
        $inBlockComment = $false
        $lineNumber = 0
        foreach ($line in Get-Content -LiteralPath $file.FullName) {
            ++$lineNumber
            $clean = Remove-CommentsFromLine -Line $line -InBlockComment ([ref]$inBlockComment)
            if ([string]::IsNullOrWhiteSpace($clean)) {
                continue
            }

            foreach ($token in $forbidden) {
                if ($clean -match $token.Pattern) {
                    $allowed = $null
                    foreach ($entry in $baselineAllowlist) {
                        if ($token.Name -ne $entry.Token) {
                            continue
                        }
                        if ($file.FullName.EndsWith($entry.Suffix, [System.StringComparison]::OrdinalIgnoreCase)) {
                            $allowed = $entry
                            break
                        }
                    }

                    $violations.Add([pscustomobject]@{
                        Path = $file.FullName
                        Line = $lineNumber
                        Token = $token.Name
                        Mode = $target.Mode
                        BaselineReason = if ($null -ne $allowed) { $allowed.Reason } else { '' }
                        Code = $clean.Trim()
                    })
                }
            }
        }
    }
}

$enforcedViolations = @($violations | Where-Object { $_.Mode -eq 'enforced' })
$baselineViolations = @($violations | Where-Object { $_.Mode -eq 'baseline' })
$knownBaseline = @($baselineViolations | Where-Object { $_.BaselineReason -ne '' })
$unexpectedBaseline = @($baselineViolations | Where-Object { $_.BaselineReason -eq '' })

Write-Host '=== HPC Hot-Path Audit ==='
Write-Host ("Scanned targets: {0}" -f $targets.Count)
Write-Host ("Enforced violations: {0}" -f $enforcedViolations.Count)
Write-Host ("Known baseline debt: {0}" -f $knownBaseline.Count)
Write-Host ("Unexpected baseline violations: {0}" -f $unexpectedBaseline.Count)

foreach ($entry in $knownBaseline) {
    Write-Host ("KNOWN {0}:{1} token={2} reason={3}" -f $entry.Path, $entry.Line, $entry.Token, $entry.BaselineReason)
}

foreach ($entry in $enforcedViolations + $unexpectedBaseline) {
    Write-Host ("ERROR {0}:{1} token={2} code={3}" -f $entry.Path, $entry.Line, $entry.Token, $entry.Code)
}

if (($enforcedViolations.Count + $unexpectedBaseline.Count) -gt 0) {
    exit 1
}

exit 0
