#include <atomic>
#include <iostream>
#include "Sources/generator/runtime_runner.h"
int main() {
    sudoku_hpc::GenerateRunConfig cfg{};
    cfg.box_rows = 4;
    cfg.box_cols = 3;
    cfg.target_puzzles = 1;
    cfg.difficulty_level_required = 7;
    cfg.required_strategy = sudoku_hpc::RequiredStrategy::SueDeCoq;
    cfg.threads = 16;
    cfg.fast_test_mode = true;
    cfg.max_total_time_s = 8;
    cfg.output_folder = "generated_sudoku_files";
    cfg.output_file = "tmp_nomonitor_sdc.txt";
    std::atomic<bool> cancel{false};
    std::atomic<bool> pause{false};
    auto result = sudoku_hpc::run_generic_sudoku(cfg, nullptr, &cancel, &pause, nullptr, nullptr);
    std::cout << "accepted=" << result.accepted << " written=" << result.written << " attempts=" << result.attempts << " rejected=" << result.rejected << "\n";
    return 0;
}
